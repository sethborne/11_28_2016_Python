from django.shortcuts import render, redirect, HttpResponse
from .models import Email

# Create your views here.

def index(request):
    # response = "Hello, I am your first request!"
    if not 'errors' in request.session:
        request.session['errors'] = []
    return render(request, 'email_valid/index.html')

def emailcreate(request):
    if request.method == "POST":
        result = Email.emailMgr.register(request.POST['email']) #class.var@funct end.regfunct()
        if result[0]:
            request.session['email'] = result[1].email
            request.session.pop('errors')
            return redirect('/success')
        else:
            request.session['errors'] = result[1]
            return redirect('/')
    else:
        return redirect('/')
#
def success(request):
    emails = Email.emailMgr.all()
    #this brings all the shit over?
    return render (request, 'email_valid/success.html', {'emails': emails, 'your_email': request.session.get('email')})
    return redirect('/')
