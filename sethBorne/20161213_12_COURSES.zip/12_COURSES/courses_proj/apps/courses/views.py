from django.shortcuts import render, redirect
from models import Course ##This

# Create your views here.
def index(request):
    context = {
        'courses' : Course.objects.all()
    }
    return render(request, 'courses/index.html', context)  ##CHANGE THIS LINK

def create(request):
    Course.objects.create(name=request.POST['name'], description=request.POST['description'])
    # print ['description']
    return redirect('/')

def delete(request, id):
    courseDelete = Course.objects.get(id=id)

    if request.method == "GET":
        return render(request, 'courses/delete.html', { 'course' : courseDelete })

    courseDelete.delete()
    return redirect('/')
