from django.shortcuts import render, redirect, HttpResponse
from random import randint
import datetime
# from models import User

def index(request):
    if not "totalGold" in request.session:
        request.session['totalGold'] = 0
    if not "activity" in request.session:
        request.session['activity'] = []
    return render(request, 'game/index.html')

def gold(request):
    # MAKE DICTIONARY FOR PLACES!
    location = request.POST['action']
    gold = 0
    if location == "pond":
        gold = 0
    if location =="farm":
        gold = randint(0,11)
    if location == "house":
        gold = randint(0,6)
    if location =="cave":
        gold = randint(0,21)
    if location == "casino" and request.session['totalGold'] > 0:
        gold = randint(-(abs(request.session['totalGold'])*2-1),abs(request.session['totalGold'])*2)
    elif location == 'casino' and request.session['totalGold'] <= 0:
        gold = 0
        gains = 'lost'
        request.session['activity'].append(['No dice! You\'re broke. Make some money before playing your luck at the {}! {}'.format(location,datetime.datetime.now().strftime("%Y-%m-%d %H:%M")),gains])
        print (request.session['activity'])
        return redirect('/')
    if not location == 'pond':
        request.session['totalGold'] += gold
        gains = "gained" if gold >= 0 else "lost"
        request.session['activity'].append(['You {} {} gold at the {} at {}'.format(gains, abs(gold), location, datetime.datetime.now().strftime("%Y-%m-%d %H:%M")), gains])
    if location == 'pond':
        request.session['totalGold'] += gold
        gains = "gained" if gold >= 0 else "lost"
        request.session['activity'].append(['You drowned in the pond at {}! {} was used to pay for your funeral'.format(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), request.session['totalGold']), 'special'])
        request.session['totalGold'] = 0
        request.session['gameover'] = 1
    if request.session['totalGold'] < 1:
        request.session['gameover'] = 1
        request.session['totalGold'] = 0

    # try:
    #     User.objects.create(username=session['username'],gold=gold)
    # except:
    #     # FIND UPDATE ROUTINE
    #     User.objects.update(username=session['username'],gold=gold)
    return redirect('/')

def reset(request):
    request.session.clear()
    return redirect('/')
