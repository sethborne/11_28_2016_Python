from __future__ import unicode_literals

from django.apps import AppConfig


class RwAppConfig(AppConfig):
    name = 'rw_app'
